package progavanzada.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import progavanzada.model.Resultado;
@Repository
public interface ResultadoRepository extends JpaRepository<Resultado, Integer> {
	Resultado findById(int id);

	List<Resultado> findByNombre(String nombre);
}
