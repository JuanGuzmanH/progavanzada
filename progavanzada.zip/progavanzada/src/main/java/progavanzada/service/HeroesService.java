package progavanzada.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import progavanzada.model.Heroes;
import progavanzada.repository.HeroesRepository;
@Service
public class HeroesService implements IHeroesService {
	@Autowired
    HeroesRepository hero;
	@Override
	public List<Heroes> listarpersonas() {
		// TODO Auto-generated method stub
		return hero.findAll();
	}

	@Override
	public Heroes encontrarporId(int id) {
		// TODO Auto-generated method stub
		return hero.findById(id);
	}


	@Override
	public void guardar(Heroes heroe) {
		// TODO Auto-generated method stub
        hero.save(heroe);
	}

	@Override
	public void eliminarporId(int id) {
		// TODO Auto-generated method stub
	    hero.deleteById(id);
	}

	@Override
	public Heroes encontrarporNombre(String nombre) {
		// TODO Auto-generated method stub
		return hero.findByNombre(nombre);
	}

}
