package progavanzada.service;

import java.util.List;

import progavanzada.model.Heroes;


public interface IHeroesService {
	List<Heroes> listarpersonas();

	Heroes encontrarporId(int id);

	Heroes encontrarporNombre(String nombre);

	void guardar(Heroes heroe);

	void eliminarporId(int id);
}
