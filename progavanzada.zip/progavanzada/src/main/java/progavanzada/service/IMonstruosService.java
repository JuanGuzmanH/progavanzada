package progavanzada.service;

import java.util.List;

import progavanzada.model.Monstruos;

public interface IMonstruosService {
	List<Monstruos> listarpersonas();

	Monstruos encontrarporId(int id);

	Monstruos encontrarporNombre(String nombre);

	void guardar(Monstruos monstruo);

	void eliminarporId(int id);
}
